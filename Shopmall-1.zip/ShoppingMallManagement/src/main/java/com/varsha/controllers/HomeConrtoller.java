package com.varsha.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeConrtoller {
	
	
	
	@RequestMapping("/home")

	public String redirect()
	{
		return "homepage";
	}
	
	@RequestMapping("/login")

	public String redirect1()
	{
		return "loginpage";
	}
	
	
    @RequestMapping("/women")
	public String redirect2()
	{
		return "clothingpage";
	}

    @RequestMapping("/westside")
   	public String redirect3()
   	{
   		return "westsidepage";
   	}
    
    @RequestMapping("/Fab")
   	public String redirect4()
   	{
   		return "fabindiapage";
   	}
    
    @RequestMapping("/soch")
   	public String redirect5()
   	{
   		return "sochpage";
   	}
    
 
    @RequestMapping("/forevernew")
   	public String redirect6()
   	{
   		return "forever";
   	}
    
    @RequestMapping("/back")
   	public String redirect7()
   	{
   		return "clothingpage";
   	}
    @RequestMapping("/Men")
   	public String Mens()
   	{
   		return "Men'sclothing";
   	}
    
    @RequestMapping("/makeup")
   	public String makeup()
   	{
   		return "Makeup";
   	
   	} 
    @RequestMapping("/BS")
   	public String BS()
   	{
   		return "btos";
   	} 
    
    @RequestMapping("/Facecream")
   	public String Facecream()
   	{
   		return "mac";
   	}
    
    @RequestMapping("/Eyeliner")
   	public String Eyeliner()
   	{
   		return "lakme";
   	}
    
  
    @RequestMapping("/Books")
   	public String Books()
   	{
   		return "Bookspage";
   	}
    
    @RequestMapping("/Heels")
   	public String Heels()
   	{
   		return "Heelspage";
   	}
    @RequestMapping("/shoe")
   	public String shoes()
   	{
   		return "Shoespage";
   	}
    @RequestMapping("/Sandals")
   	public String Sandals()
   	{
   		return "Sandalpage";
   	}
    @RequestMapping("/kurti")
    public String redirect8()
    {
    return "kurta";
    }
   
    @RequestMapping("/shirt")
    public String redirect9()
    {
    return "saree";
    }
   
    @RequestMapping("/dress")
    public String redirect10()
    {
    return "dresses";
    }
   
   
    @RequestMapping("/tops")
    public String redirect11()
    {
    return "tops";
    }
   
    @RequestMapping("/dressmaterial")
    public String dressmaterial()
    {
    return "dressmaterial";
    }
   
    @RequestMapping("/masks")
    public String redirect12()
    {
    return "masksjsp";
    }
   
    @RequestMapping("/pant")
    public String redirect13()
    {
    return "pants";
    }
   
    @RequestMapping("/duppata")
    public String redirect14()
    {
    return "dupatta";
    }
   
    @RequestMapping("/buy")
    public String redirect15()
    {
    return "buynow";
    }
    
    
    @RequestMapping("/order")
    public String redirect16()
    {
    return "order";
    }
   
    @RequestMapping("/place")
    public String redirect17()
    {
    return "placed";
    }
    
    @RequestMapping("/jack")
    public String redirect18()
    {
    return "jack";
    }
    
    @RequestMapping("/zodiac")
    public String redirect19()
    {
    return "zodiac";
    }
    
    @RequestMapping("/AB")
    public String redirect20()
    {
    return "A&B";
    }
    
    @RequestMapping("/HF")
    public String redirect21()
    {
    return "h&fjsp";
    }
   
    @RequestMapping("/bag")
    public String redirect22()
    {
    return "bags";
    }
   
    @RequestMapping("/acc")
    public String redirect23()
    {
    return "accesories";
    }
    
    @RequestMapping("/buyj")
    public String buyj()
    {
    return "buyj";
    }
    
    @RequestMapping("/buys")
    public String buys()
    {
    return "buys";
    }
    
    @RequestMapping("/buysh")
    public String buysh()
    {
    return "buysh";
    }
    
    @RequestMapping("/buyb")
    public String buyb()
    {
    return "buyb";
    }
    
    @RequestMapping("/buya")
    public String buya()
    {
    return "buya";
    }
    
    
    @RequestMapping("/buy1")
    public String buy1()
    {
    return "buy1";
    }
    
    @RequestMapping("/buyh")
    public String buyh()
    {
    return "buyh";
    }
    
    @RequestMapping("/buym")
    public String buym()
    {
    return "buym";
    }
    
    @RequestMapping("/buyl")
    public String buyl()
    {
    return "buyl";
    }
   
    
    
    
}
